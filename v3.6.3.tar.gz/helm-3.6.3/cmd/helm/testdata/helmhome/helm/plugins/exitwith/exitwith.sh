#!/bin/bash
exit $*
