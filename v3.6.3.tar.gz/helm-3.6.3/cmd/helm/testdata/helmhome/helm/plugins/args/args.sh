#!/bin/bash
echo $*
